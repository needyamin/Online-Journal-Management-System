 <!-- Bootstrap core JavaScript -->
   <script src="assets/js/coustom.js"></script>
<script src="assets/js/bootstrap-tagsinput.min.js"></script>
    <script src="assets/js/bootstrap-tagsinput-angular.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
    

<!-- DAta Table-->
<link rel="stylesheet" type="text/css" href="assets/datatable/datatables.css"/>
<script type="text/javascript" src="assets/datatable/datatables.js"></script> 
    
    

<script>$(document).ready(function() {
    $('#example').DataTable();
} );</script>


    
<!-- end Table-->    

</body>

</html>

    
