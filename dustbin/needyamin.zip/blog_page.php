<?php 
require"function/database.php"; 
require"function/siteconfig.php";
require"index/header.php";?> 


<body>
<div class="container">
        
<!--start main body post code-->        
<div class="col-main">

    
    
<?php 
$blog = $_GET['blog'];     
$sql="SELECT * FROM opaar_blog WHERE blog_slug='$blog'";
$stmt = $con->prepare($sql);   
$stmt->execute();   
 
if ($stmt->rowCount() > 0) {
// output data of each row
while ($blog = $stmt->fetch()) { $blog_id_get = $blog["id"]; $user_id = ''. $blog["user_id"].'' ?>    
    
<div class="col-card">
<div id="post"> 

<?php                                
if($cdn == '1'){;?><img src="https://cdnashbd.s3-ap-southeast-1.amazonaws.com/opaar/<?php echo''. $blog["blog_cover"].'';?>" id="img_cover" onerror="this.onerror=null; this.src='admin/assets/img/cover_180.png'"> <div id="break"> </div> <?php } else {;?>   
<img src="uploads/<?php echo''. $blog["blog_cover"].'';?>" id="img_cover" onerror="this.onerror=null; this.src='admin/assets/img/cover_180.png'"> <div id="break"> </div>    
<?php };?>  
    
<H3> <?php echo''. $blog["blog_title"].'';?></H3>
    
<?php 
$sql1="SELECT * FROM opaar_users WHERE id='$user_id'";
$stmt = $con->prepare($sql1);   
$stmt->execute(); 
$row = $stmt->fetch();
echo 'Posted by: <b> '.$row['1'].'</b>';?>
                                

<p> <?php echo''. $blog["blog_description"].'';?></p> 
    
    
 
<?php }} else {echo "<div class='col-card' style='padding:10%;'>No Journals Found..</div>";};?>
    
     
    
          
</div></div>           

<div style="clear:both"></div> 
    
    
    
    
<div class="col-card">   
<h3> <div class="sep">Blog Comments</div></h3> 


     

          
   
    
     
</div>
            
    
    
    
</div>
        
        
<!--stop main body post code-->       
<?php include"index/sidebar.php";?>
        

    
        </div>
    
      

    </body>
   
<?php require"index/footer.php";?>
