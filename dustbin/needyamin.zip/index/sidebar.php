<?php require"function/siteconfig.php" ;?>        
        
<div class="col-sidebar">
            
            
<h3 style="font-style:oblique; font-size:22px;">Sidebar </h3><hr style="border: 5px solid green; margin-left:5px;">
            
 <table style="border:0px solid black; width:95%; text-align:center;" align="center"> 
     <?php 
     $i='0';
     $sql_blog = "SELECT * FROM opaar_blog ORDER BY blog_title DESC limit 0,5;";
     $stmt = $con->prepare($sql_blog);   
     $stmt->execute();   
     if ($stmt->rowCount() > 0) {
     while ($blog = $stmt->fetch()) { $i++;?>
    
    
<tr><td style="font-size:20px; font-weight:bold;">
    
<?php                                
if($cdn == '1'){;?><img style="width:100%; height:150px; border:2px solid blue;" src="https://cdnashbd.s3-ap-southeast-1.amazonaws.com/opaar/<?php echo''. $blog["blog_cover"].'';?>" id="img_cover" onerror="this.onerror=null; this.src='admin/assets/img/cover_180.png'" width="30%;"> <div id="break"> </div> 
<?php } else {;?>   
<img style="width:100%; height:150px; border:2px solid blue;" src="uploads/<?php echo''. $blog["blog_cover"].'';?>" id="img_cover" onerror="this.onerror=null; this.src='admin/assets/img/cover_180.png'" width="30%;"> <div id="break"> </div>    
<?php };?>  
    
    
<br>
    <p style="font-style:initial; font-size:17px;text-align: justify;"> <?php echo $i;?>. <?php echo $blog['blog_title'];?></p>
</td></tr>
     
     
<tr><td> <p style="font-style:initial; font-size:16px;text-align: justify;"><?php echo''. strip_tags(substr($blog["blog_description"],0,205)).'.. </p><hr>';?> </td></tr>  
     
     <?php }};?>
    
    </table>
    
    </div>