
<html>
<header>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    
   <!--<script>alert('We are working on our site. Please visit us next month 1 July 2020')</script>-->
    
<!-- Keywords Made by Yamin -->
  <meta name="description" content="Open Source Journal">
  <meta name="keywords" content="bio-science, journal, Bangladesh">
  <meta name="author" content="Md Hassan Shamim">
<!-- SEO Meta Tag end -->

    
    
    <title>Welcome to Opaar </title>
    <link href="style.css" rel="stylesheet" type="text/css">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <script>
      $(document).ready(function() {
        $('.container').addClass('container-loaded');
      });
    </script>
      

<ul>
  <li><a class="active" href="index.php">Home</a></li>
  <li><a href="#news">Sitemap</a></li>
  <li><a href="#contact">Contact</a></li>
  <li><a href="#about">About</a></li>
    
<div class="desktop-only">
<div id="license">ISSN xxxx-xxxx (Online), ISSN xxxx-xxxx (Print)</div>
</div>
    
</ul>
    
    
    
    
    
    
    
    

<div class="header">
    <table id="header_table_logo" width="80%"> 
        <tr><td> <img src="assets/img/logo.png" id="header_logo" > </td> 
        <td></td>
        </tr></table>
    
    
    </div>
    
<div class="menu"> 
<div class="menu2">     
    
    
    
    
<!--<div class="desktop-onlyxx">-->
    
<div class="navbar">
  <a href="index.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
  <a href="#news">News</a>
  <div class="dropdown">
    <button class="dropbtn">Dropdown 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div>
    
 <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
    
    
</div>


<!--</div>-->
    
    
    
    
    </div> </div>
    
    <div id="istyle" style="margin-bottom: 3px;"> </div>

    

    
<div id="slidershow-container-background">   
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="http://cssslider.com/sliders/demo-17/data1/images/picjumbo.com_img_5948.jpg" style="width:100%; height: 40%;">
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="http://cssslider.com/sliders/demo-17/data1/images/picjumbo.com_hnck0391.jpg" style="width:100%; height: 40%;">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="http://cssslider.com/sliders/demo-17/data1/images/picjumbo.com_hanv9909.jpg" style="width:100%; height: 40%;">
  <div class="text">Caption Three</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
</div> 
<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

</header>
<div style="clear:both"></div>
    
