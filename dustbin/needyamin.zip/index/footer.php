 
      <div style="clear:both"></div> 
    
    
<div id="istyle" style="margin-top: 3px;"> </div>
<div class="footer"> 
    
    <div id="footer_left"> ISSN xxxx-xxxx (Online), ISSN xxxx-xxxx (Print) </div> 
    <div id="footer_right">     <img src="assets/img/logo.png" style="width: 100px;"> 
</div> 
    
    </div>  
    
<div id="footer_end">© 2020 Yamin Hossain Shohan |  All rights reserved.</div>

</html>
