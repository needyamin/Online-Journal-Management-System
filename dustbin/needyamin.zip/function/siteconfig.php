<?php 
$cdn = '0'; // 0 mean trun off cdn and 1 mean ON
?> 
